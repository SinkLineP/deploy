import React from 'react'
import './Classes.scss'
export default function Classes() {
    return (
        <div className="glavn">
            <div className="name-classes">
                <strong>Коррекційні зайняття</strong>
            </div>
            <div className="text-classes">
                <p>Для дітей з тяжкими порушеннями мовлення у поєднанні з <br />порушеннями інтелектуального розвитку або затримкою <br />    психічного розвитку</p>
            </div>

            <table>
                <tbody>
                    <tr>
                        <td><button type="button" class="btn btn-outline-primary btn-1">1-4 класи</button></td>
                        <td><button type="button" class="btn btn-outline-primary btn-2">5-10 класи</button></td>
                    </tr>
                </tbody>
            </table><br /><br /><br />

            <table>
                <tbody>
                    <tr>
                        <td><div className="predmet">
                            <p className="bottom-bord">Розвиток&nbsp;мовлення</p>
                            <p className="bottom-bord">Ритміка</p>
                            <p className="bottom-bord">Лікувальна&nbsp;фізкультура</p>
                            <p className="bottom-bord">Соціально&nbsp;-&nbsp;побутове&nbsp;орієнтування</p>
                        </div></td>
                        <td><div className="mini-text">
                            <p>На уроках Української мови в перших і других класах дітей навчають алфавіту та написанню літер. Навчання проводиться с урахуванням особливостей кожної дитини. Ініціюється запуск мовлення в немовних дітей (при фізіологічній можливості). Розвиток зв'язного мовлення. Формування і розвиток різних функцій мовлення: пояснення, опис, ініціювання, задавання запитань та інше. Навчання проводиться с урахуванням особливостей кожної дитини. </p>
                        </div></td>
                    </tr>
                </tbody>
            </table>








        </div>
    )
}
